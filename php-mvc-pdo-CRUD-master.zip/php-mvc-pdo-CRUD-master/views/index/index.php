<div class="container">
	<div class="row">
		<div class="col-md-12">
			<center><h1>CRUD - OFAAOFICIAL - MVC</h1></center>
			<br>			
			<center>
			<button type="button" onclick="ModalRegister();" class="btn btn-success">Agregar usuario</button>
			</center>
			<br>
		<div id="information">
			<button onclick="read();"></button>
		</div>			
		</div>
	</div>
</div>

