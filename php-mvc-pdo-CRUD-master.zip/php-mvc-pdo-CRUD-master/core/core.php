<?php
/*
	CRUD creado por Oscar Amado
	Contacto: oscarfamado@gmail.com
*/
require_once('models/db.php');
require_once('models/Administrator.php');