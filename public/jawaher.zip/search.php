<?php include 'header.php'; ?>

    <section class="slider"> 
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3 class="text-center text-white" style="padding-top: 20%;">
                         نرحب بكم في موقع جواهر للعمل عن بعد للوظائف النسائية
                         </h3>               
                    </div>
                </div>
         </div>
    </section>       

</br>
</br>
<section class="blogs" id="jobs"> 
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="text-center" style="padding-top:.5%;color: rgb(66 15 66);">
                   نتائج البحث عن وظيفة
                     </h3>               
                </div>
            </div>
        </br>

            <div class="row" style="direction:rtl;">
                 <!-- The signup Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content" style="color: #402558;">

      <!-- Modal Header -->
      <div class="modal-header" style="direction: rtl;">
        <h4 class="modal-title color-white text-center">يرجى تسجيل الدخول اولا</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
 <form  class="text-right" role="form" action="<?php echo $_SERVER['PHP_SELF']?>"  method="POST"  >
                      <div class="form-group col-sm-12" style="float:right;">                                                                                        <label>اسم المستخدم </label>

                        <input type="text" name="name" value="<?php if(isset($_POST['name'])){echo $_POST['name'];}?>" class="form-control  rounded-0 p-3"   placeholder="">   
                      </div>
                         <div class="form-group col-sm-12" style="float:right;"> 
                             <label> كلمة المرور </label>

                        <input type="password" name="pass" value="<?php if(isset($_POST['pass'])){echo $_POST['pass'];}?>" class="form-control  rounded-0 p-3" placeholder=" ">   
                      </div>   
      <div class="form-group  col-sm-12" style="float:right;"> 
                     <button type="submit" name="login" style="width: 49%;color:#402558; border: 1px solid #402558;float:right;" class="btn p-2 rounded-0" >دخول</button>
                         <a  style="width:49%;border: 1px solid #402558;color:#402558;float:left;" class="btn rounded-0 p-2" href="signup.php">انشاء حساب</a>
                     </div>
                    </form></div>

     
    </div>
  </div>
</div>
              <!--end The signup Modal -->
       
                 <?php 
    if(isset($_POST['search'])){

$key=$_POST['key'];
$GLOBALS['query']="SELECT * FROM `jw_jobs` WHERE name LIKE '%$key%'  ";
$h_display_item=$con->prepare($GLOBALS['query']);
    $h_display_item->execute();
    $h_empty= $h_display_item->rowcount();
        if($h_empty>0){
if(isset($_SESSION['n'])&&!empty($_SESSION['n'])){
 while($row=$h_display_item->fetch()) :

           echo'
<a type="button" href="descripe.php?id='.$row['id'].'" class="btn btn-success m-1 jobl"> '.$row['name'].'</a>';
endwhile;}elseif(!isset($_SESSION['id'])&&empty($_SESSION['id'])){
 while($row=$h_display_item->fetch()) :

           echo'
<a type="button" href="#" class="btn btn-success m-1 jobl" data-toggle="modal" data-target="#myModal">'.$row['name'].'</a>';
endwhile;}}else{
        echo '<h6 class="text-center bg-info text-light"> لايوجد نتائج مطابقة للبحث</h6>';
        
        }
    
    }
?>
     </div>
</section> 
</br>
</br>

<?php include 'footer.php'; ?> 