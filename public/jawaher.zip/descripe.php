<?php include 'header.php'; ?> 
</br>
</br></br>
</br>
<section class="contact">

      <div class="container">
        <div class="row box1">
              <div class="col-md-12 col-sm-12">
             <div class="">
                <h3 class="text-center" style="color: #402558;">  تفاصيل الوظيفة</h3>
</br>
            </div>
      </div>
           <?php
if(isset($_GET['id'])){
$id=$_GET['id'];
$uid=$_SESSION['id'];
    $GLOBALS['id']=$id;
    $pro_fetch=$con->prepare("select * from jw_regestered_jobs where job_id=$id and user_id=$uid");
		$pro_fetch->setFetchMode(PDO:: FETCH_ASSOC);
		$pro_fetch->execute();
        $cou=$pro_fetch->rowCount();
    
    if($cou ==0){
        $pro_fetch=$con->prepare("select * from jw_jobs where id=$id ");
		$pro_fetch->setFetchMode(PDO:: FETCH_ASSOC);
		$pro_fetch->execute();
        $cou=$pro_fetch->rowCount();
    
    if($cou > 0){
    while($row=$pro_fetch->fetch()) :
echo'
            <div class="col-sm-12" style="margin-bottom: 10px;border-bottom: 2px solid #676396; ">
            
<h3 class="text-center ">
                        <span class=" ext-center">'.$row['name'].' </span>
                    </h3>
  </div>        
<div class="col-sm-6 ">
               <p class="text-right"><span class="fa fa-building "></span> '.$row['jeha'].' </p>
            </div>
            <div class="col-sm-6 ">

                <p class="text-left">
                <span class="ion-android-calendar"></span>'.$row['publishdate'].'</p>
               
            </div>
    
    <div class="col-sm-12 text-right">
            
             <p class="par text-right">
               
<h6 class=" text-right ">
                       وصف الوظيفة <span class="span1 ion-compose">  </span>
                    </h6>
'.$row['description'].' </p>
           <p class="par loader  text-right">
               
<h6 class=" text-right ">
                       اماكن العمل <span class="span1 ion-location">  </span>
                    </h6>
'.$row['address'].'</p>
            <p class="par loader  text-right">
               
<h6 class=" text-right ">
                       الشروط <span class="span1 ion-clipboard"></span>
                    </h6>
 '.$row['constracts'].'     </p>
                 <p class="par loader  text-right">
               
<h6 class=" text-right ">
                        <span class="span1 ion-calendar"></span>  تاريخ التقديم
                    </h6>
يبدأ: '.$row['startdate'].'
ينتهي: '.$row['enddate'].'
</br>
<a type="button" data-toggle="modal" data-target="#myModal24" class="btn btn-success m-1 jobl">أضغط هنا</a>

للتقديم على الوظيفة 
</p>


            </div>
            
        <!-- The signup Modal -->
<div class="modal" id="myModal24">
  <div class="modal-dialog">
    <div class="modal-content" style="color: #402558;">

      <!-- Modal Header -->
      <div class="modal-header" style="direction: rtl;">
        <h4 class="modal-title color-white text-center">للتاكيد اضغط موافق</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
 <form  class="text-right" role="form" action="?do=sure"  method="POST"  >
                      <div class="form-group col-sm-12" style="float:right;">                                                                                        <label>اسم المستخدم </label>
 <input type="text" name="user" value="'.$_SESSION['n'].'"  readonly class="form-control  rounded-0 p-3"   placeholder=""> 
            <input value="'.$_SESSION['id'].'" readonly hidden="hidden" type="text" name="usid" value="" class="form-control  rounded-0 p-3"   placeholder="">      </div>
                         <div class="form-group col-sm-12" style="float:right;"> 
                             <label>  اسم الوظيفة </label>

                        <input type="text" name="jobname" readonly value="'.$row['name'].'" class="form-control  rounded-0 p-3" placeholder=" "> 
                             <input type="text" name="jobid" hidden="hidden" value="'.$row['id'].'" class="form-control  rounded-0 p-3" placeholder=" "> 
                      </div>   
      <div class="form-group  col-sm-12" style="float:right;"> 
                      <button type="submit" name="sure" style="width: 49%;color:#402558; border: 1px solid #402558;float:right;" class="btn p-2 rounded-0" >موافق</button>
                         <a data-dismiss="modal" style="width:49%;border: 1px solid #402558;color:#402558;float:left;" class="btn rounded-0 p-2" href="#">الغاء</a>
                     </div>
                    </form></div>

     
    </div>
  </div>
</div>
              <!--end The signup Modal -->
';          endwhile;
    }
        
    }elseif($cou == 1){
    $pro_fetch=$con->prepare("select * from jw_jobs where id=$id ");
		$pro_fetch->setFetchMode(PDO:: FETCH_ASSOC);
		$pro_fetch->execute();
        $cou=$pro_fetch->rowCount();
    
    if($cou > 0){
    while($row=$pro_fetch->fetch()) :
echo'
            <div class="col-sm-12" style="margin-bottom: 10px;border-bottom: 2px solid #676396; ">
            
<h3 class="text-center ">
                        <span class=" ext-center">'.$row['name'].' </span>
                    </h3>
  </div>        
<div class="col-sm-6 ">
               <p class="text-right"><span class="fa fa-building "></span> '.$row['jeha'].' </p>
            </div>
            <div class="col-sm-6 ">

                <p class="text-left">
                <span class="ion-android-calendar"></span>'.$row['publishdate'].'</p>
               
            </div>
    
    <div class="col-sm-12 text-right">
            
             <p class="par text-right">
               
<h6 class=" text-right ">
                       وصف الوظيفة <span class="span1 ion-compose">  </span>
                    </h6>
'.$row['description'].' </p>
           <p class="par loader  text-right">
               
<h6 class=" text-right ">
                       اماكن العمل <span class="span1 ion-location">  </span>
                    </h6>
'.$row['address'].'</p>
            <p class="par loader  text-right">
               
<h6 class=" text-right ">
                       الشروط <span class="span1 ion-clipboard"></span>
                    </h6>
 '.$row['constracts'].'     </p>
                 <p class="par loader  text-right">
               
<h6 class=" text-right ">
                        <span class="span1 ion-calendar"></span>  تاريخ التقديم
                    </h6>
يبدأ: '.$row['startdate'].'
ينتهي: '.$row['enddate'].'
</br>
</br>
</br>
<div class="alert alert-success">
 تم التسجيل في هذة الوظيفة بنجاح من قبل
</div>
</p>
</div>
';         
endwhile;
}        
}
}
?>
        </div>
        </div>
</section>
</br>
<?php include 'footer.php'; ?> 