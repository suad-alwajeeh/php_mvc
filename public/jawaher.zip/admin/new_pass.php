<?php
ob_start();
//error_reporting(0);
//ini_set('display_errors', 0);
include '../db_con/db_con.php';

?>
<?php include 'header.php'; ?>

   <!--start login-->
        <section class="login">
            <div class="container">
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8 ">
                        <div class="log">
                            <h5 class="text-right">
لاعادة تعيين كلمة المرور ادخل اسم المستخدم وكلمه المرور الجديدة بشكل صحيح</br>
                                </h5>
                        <?php

if($_SERVER['REQUEST_METHOD']=='POST'){
$username=$_POST['name'];
$password=$_POST['password'];
    $password1=$_POST['password1'];
$hashpassword= sha1($password);
    if($password==$password1){
 $pro_fetch=$con->prepare("select * from jw_user where name= '$username'");
 $pro_fetch->setFetchMode(PDO:: FETCH_ASSOC);
		$pro_fetch->execute();
        $cou=$pro_fetch->rowCount();
    
if($cou > 0){


                $update=$con->prepare("UPDATE `jw_user` SET `name`='$username',`password`='$hashpassword',`con_password`='$password' where name= '$username' ");
               if($update->execute()){

                  header('location:index.php');  
            exit();
              }else{
              echo'none';
              } 
}else{
     $success='<div class="alert alert-danger" style="text-align:center;"> تاكد من كتابة اسم المستخدم بشكل صحيح</div>';
    echo $success;

}
    }
else{
         
 $success='<div class="alert alert-danger" style="text-align:center;">  تاكد من كتابة كلمة المرور بشكل صحيح بكلا المربعين</div>';
    echo $success;
     
    }
}

?>
               </br>
                        <form class="form text-right" action="<?php echo $_SERVER['PHP_SELF']?>"  method="POST">
                         <div class="form-group">
                          <input type="text" name="name"  autocomplete="off" class="text-right form-control" placeholder="الاسم" >
                        </div>
                        <div class="form-group">
                            <input type="text" name="password" class=" text-right form-control" placeholder="كلمة المرور" >
                          </div>
                             <div class="form-group">
                            <input type="text" name="password1"  autocomplete="new-password" class=" text-right form-control" placeholder="كلمة المرور تكرار" >
                          </div>
                          <div class="form-group">
                                    <button name="submit" type="submit" class="btn btn-outline-dark">دخول</button>
                          </div>
                          </form>
                          </div>
                    </div>
                    <div class="col-md-2"></div>
                </div>    
            </div>
        </section>

   <!--start login-->

   </body>
   </html>
<?php
ob_end_flush();
?>