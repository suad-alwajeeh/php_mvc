<?php
ob_start();
session_start();
if(isset($_SESSION['username'])){
}else{
header('location:index.php');
exit();
}
include '../db_con/db_con.php';
?>
<?php include 'header.php'; ?>
<?php include 'nav.php'; ?>


   <!--add form-->
   <section class="header " >
    <div class="container-fluid">
        <div class="row">
            <div class=" col-sm-12">
                <h4 class="text-center text-black">تعديل وظيفة</h4>
             </div>
             <div class="col-1"></div>
             <div class="col-10">
                 
                   <?php
 $do = isset($_GET['do']);
if($do == 'add'){
    if(isset($_POST['addbtn'])){
$id= $_POST['id'];$title= $_POST['title'];
$jehplace=$_POST['jehplace'];
$jeha= $_POST['jeha'];    
$enddate= $_POST['enddate'];
$startdate= $_POST['startdate'];
$descrip= $_POST['descrip'];
$constract= $_POST['constract']; 
        echo $constract ;
$text = str_replace("'", "\'", $title);
$text2 = str_replace("'", "\'", $jehplace);
$text3 = str_replace("'", "\'", $jeha);  
$text4 = str_replace("'", "\'", $enddate);  
$text5 = str_replace("'", "\'", $startdate);
$text7 = str_replace("'", "\'", $descrip);  
$text8 = str_replace("'", "\'", $constract);        
            $update=$con->prepare("UPDATE `jw_jobs` SET`name`='$text',`jeha`='$text3',`address`='$text2',`startdate`='$text5',`enddate`='$text4',`description`='$text7',`constracts`='$text8' WHERE id=$id");
               if($update->execute()){
                 header('location:dashboard.php');  
             exit();      
 $success='<div class="alert alert-success" style="text-align:center;"> ..تم الاضافة بنجاح..</div>';
    echo $success;
              }
     else{
          $success='<div class="alert alert-danger" style="text-align:center;">يجب ان تدخل جميع الحقول بشكل صحيح</div>';
            echo $success;
        }
    }
    }
?>     
                   <?php
if(isset($_GET['id'])){
$id=$_GET['id'];
    $GLOBALS['id']=$id;
		$pro_fetch=$con->prepare("select * from jw_jobs where id=$id ");
		$pro_fetch->setFetchMode(PDO:: FETCH_ASSOC);
		$pro_fetch->execute();
        $cou=$pro_fetch->rowCount();
    
    if($cou > 0){ ?>
                    <form action="?do=add"  method="POST" class="text-right">
                    <div class="form-group">
                                                <?php while($row=$pro_fetch->fetch()) :?>  
                        <label for="">عنوان الوظيفة</label>
                        
                        <input type="text" required
                            class="form-control" name="id" hidden="hidden" value="<?php echo $row['id'] ;?>"  >
                        <input type="text" required
                            class="form-control" name="title" value="<?php echo $row['name'] ;?>"  >
                        </div>
                         <div class="row">
                               <div class="form-group col-sm-12 col-md-6">
                        <label for=""> مقر العمل</label>
                        <input type="text" required
                            class="form-control" name="jehplace" value="<?php echo $row['jeha'] ;?>"  >
                        </div>
                        <div class="form-group col-sm-12 col-md-6">
                        <label for=""> اسم الجهه</label>
                        <input type="text" required
                            class="form-control" name="jeha" value="<?php echo $row['address'] ;?>" >
                        </div>
                         <div class="form-group col-sm-12 col-md-6">
                            <label for=""> ينتهي التقديم في</label>
                          <input type="date" required
                            class="form-control" name="enddate" value="<?php echo $row['enddate'] ;?>"  >
                          </div>
                        <div class="form-group col-sm-12 col-md-6">
                            <label for=""> يبدأ التقديم في</label>
                          <input type="date" required
                            class="form-control" name="startdate" value="<?php echo $row['startdate'] ;?>" >
                          </div>
                        </div>
                        <div class="form-group">
                            <label for="">وصف الوظيفة</label>
                            <textarea required style="height: 150px;" type="text"class="form-control" name="descrip" >
                                <?php echo $row['description'] ;?> </textarea>
                        </div>
                          <div class="form-group">
                            <label for="">شروط الوظيفة</label>
                            <textarea required style="height: 150px;" type="text"class="form-control" name="constract" >
                                <?php echo $row['constracts'] ;?> </textarea>
                        </div>
                                                         <?php endwhile; }
}?>   
                        <div class="form-group">
                        <button type="submit" name="addbtn"   style="width: 49%;float: ;" class="btn btn-dark">موافق</button>
                            <a href="dashboard" style="float: left;width: 49%;"  class=" btn btn-dark">عودة</a>
                            </div>
                 </form>
             </div> 
             <div class="col-1"></div>  
        </div>
    </div>
</section>
<!--add form-->

<?php
ob_end_flush();
?>