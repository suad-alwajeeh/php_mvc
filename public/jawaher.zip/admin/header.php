<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>لوحة التحكم</title>
      
      <link rel="stylesheet" href="../custom/font/ionicons/css/ionicons.min.css">
      <link rel="stylesheet" href="../custom/css/bootstrap.min.css">
      <link rel="stylesheet" href="../custom/css/dash.css">
      <script src="../custom/js/jquery3.4.1.js"></script>
       <script src="../custom/js/popper.min.js"></script> 
       <script src="../custom/js/bootstrap.min.js"></script>
       <script src="../custom/js/nicEdit.js"></script>
       <script src="../custom/js/script.js"></script>
       

</script>
       <script type="text/javascript">
     bkLib.onDomLoaded(function() {
          var myNicEditor = new nicEditor();
                 bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
         
     });
</script> 
      </head>
   <body>