    <section class="control bg-light" >
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 text-right">
                    <div class="btn-group ml-auto" role="group"  aria-label="Second group">
                            <a style="border-radius: 0px;" href="add.php" type="button" class="btn btn-outline-primary">
                            <span class="ion-android-add"></span> اضافة وظيفة  </a>
                            <a style="border-radius: 0px;" href="userjob.php" type="button" class="btn btn-outline-info">
                            <span class="ion-ios-list-outline"></span>  الوظائف المقدم عليها</a> 
                            <a style="border-radius: 0px;" href="dashboard.php" type="button" class="btn btn-outline-dark">
                            <span class="ion-ios-list-outline"></span> الوظائف</a>  
                          <a style="border-radius: 0px;" href="users.php" type="button" class="btn btn-outline-success">
                            <span class="ion-person"></span> المسجلين</a>
                    </div>
                     <div class="btn-group ml-auto" role="group" style="float:left;"  aria-label="Second group"> 
                          <a style="border-radius: 0px;" href="logout.php" type="button" class="btn btn-outline-danger">
                            <span class="ion-logout"></span>  خروج</a>
                            <a style="border-radius: 0px;" href="user.php" type="button" class="btn btn-outline-info">
                            <span class="ion-person"></span>عرض المستخدم</a> 
                    </div>
                 </div>  
            </div>
        </div>
    </section>
