<?php
ob_start();
session_start();
if(isset($_SESSION['username'])){
}else{
header('location:index.php');
exit();
}
include '../db_con/db_con.php';
?>
<?php include 'header.php'; ?>
<?php include 'nav.php'; ?>
  

   <!--add form-->
   <section class="header " >
    <div class="container-fluid">
        <div class="row">
            <div class=" col-sm-12">
                <h4 class="text-center text-black">أضافة وظيفة</h4>
             </div>
             <div class="col-1"></div>
             <div class="col-10">
    <?php
 $do = isset($_GET['do']);
if($do == 'add'){
    if(isset($_POST['addbtn'])){
$title= $_POST['title'];
$jehplace=$_POST['jehplace'];
$jeha= $_POST['jeha'];    
$enddate= $_POST['enddate'];
$startdate= $_POST['startdate'];
$publishdate= $_POST['publishdate']; 
$descrip= $_POST['descrip'];
$constract= $_POST['constract']; 
$text = str_replace("'", "\'", $title);
$text2 = str_replace("'", "\'", $jehplace);
$text3 = str_replace("'", "\'", $jeha);  
$text4 = str_replace("'", "\'", $enddate);  
$text5 = str_replace("'", "\'", $startdate);
$text6 = str_replace("'", "\'", $publishdate);
$text7 = str_replace("'", "\'", $descrip);  
$text8 = str_replace("'", "\'", $constract);        
     if($title !=null && $jehplace != null&& $jeha != null && $enddate != null && $startdate != null && $constract != null && $descrip != null){  
            $update=$con->prepare("INSERT INTO `jw_jobs`(`name`,`publishdate`,`jeha`,`address`,`startdate`,`enddate`,`description`,`constracts`) VALUES ('$text','$text6','$text3','$text2','$text4','$text5','$text7','$text8')");
               if($update->execute()){
                 header('location:dashboard.php');  
             exit();      
 $success='<div class="alert alert-success" style="text-align:center;"> ..تم الاضافة بنجاح..</div>';
    echo $success;
              }
     }else{
          $success='<div class="alert alert-danger" style="text-align:center;">يجب ان تدخل جميع الحقول بشكل صحيح</div>';
            echo $success;
        }
    }
    }
?>             
                    <form action="?do=add"  method="POST" class="text-right" >
                    <div class="form-group">
                        <label for="">عنوان الوظيفة</label>
                        <input type="text" required
                            class="form-control" name="title" value="<?php if(isset($_POST['title'])){echo $_POST['title'];}?>" >
                        </div>
                         <div class="row">
                               <div class="form-group col-sm-12 col-md-6">
                        <label for=""> مقر العمل</label>
                        <input type="text" required
                            class="form-control" name="jehplace" value="<?php if(isset($_POST['jehplace'])){echo $_POST['jehplace'];}?>" >
                        </div>
                        <div class="form-group col-sm-12 col-md-6">
                        <label for=""> اسم الجهه</label>
                        <input type="text" required
                            class="form-control" name="jeha" value="<?php if(isset($_POST['jeha'])){echo $_POST['jeha'];}?>">
                        </div>
                         <div class="form-group col-sm-12 col-md-6">
                            <label for=""> ينتهي التقديم في</label>
                          <input type="date" required
                            class="form-control " name="enddate" value="<?php if(isset($_POST['enddate'])){echo $_POST['enddate'];}?>" >
                          </div>
                        <div class="form-group col-sm-12 col-md-6">
                            <label for=""> يبدأ التقديم في</label>
                          <input type="date" required
                            class="form-control" name="startdate" value="<?php if(isset($_POST['startdate'])){echo $_POST['startdate'];}?>">
                          </div>
                             <input type="text" readonly  value="<?php  echo date('Y-m-d ');  ?>"
                            class="form-control" hidden="hidden"  name="publishdate"  >
                             
                        </div>
                        <div class="form-group">
                            <label for="">وصف الوظيفة</label>
                            <textarea  style="height: 150px;" type="text"class="form-control" name="descrip" id="" ><?php if(isset($_POST['descrip'])){echo $_POST['descrip'];}?></textarea> </div>
                          <div class="form-group">
                            <label for="">شروط الوظيفة</label>
    <textarea  style="height: 150px;" type="text"class="form-control" name="constract" id="" ><?php if(isset($_POST['constract'])){echo $_POST['constract'];}?></textarea>
                        </div>
                        
                        <div class="form-group">
                        <button type="submit" name="addbtn" style="width: 49%;" class="btn btn-dark">موافق</button>
                            <a href="dashboard" style="float: left;width: 49%;"  class=" btn btn-dark">عودة</a>
                            </div>
                 </form>
             </div> 
             <div class="col-1"></div>  
        </div>
    </div>
</section>
<!--add form-->
<?php
ob_end_flush();
?>