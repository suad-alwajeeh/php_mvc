<?php include '../db_con/db_con.php'; ?>
<?php
 $do = isset($_GET['do']);
if($do == 'gen'){
    if(isset($_POST['generate'])){
$id= $_POST['id'];
$code= $_POST['code'];
       echo $code ;
           $GLOBALS['query']="SELECT * FROM `jw_regestered_jobs` where jr_id=$id";
$h_display_item=$con->prepare($GLOBALS['query']);
    $h_display_item->execute();
    $h_empty= $h_display_item->rowcount();
        if($h_empty==1){
             $update=$con->prepare("UPDATE `jw_regestered_jobs` SET `code_number`=$code WHERE jr_id=$id");
               if($update->execute()){
                 header('location:userjob.php');  
             exit();      
 $success='<div class="alert alert-success" style="text-align:center;"> ..تم الاضافة بنجاح..</div>';
    echo $success;
              }
        }else{
        echo "not found";
        }
    }
}

if($do == 'send'){
if(isset($_POST['sendcode'])){
$id= $_POST['id'];
$uid= $_POST['userid'];
$jid= $_POST['jobid'];
           $GLOBALS['query']="SELECT * FROM `jw_regestered_jobs` where jr_id=$id and job_id=$jid and user_id=$uid";
$h_display_item=$con->prepare($GLOBALS['query']);
    $h_display_item->execute();
    $h_empty= $h_display_item->rowcount();

        if($h_empty==1){
                                   while($row=$h_display_item->fetch()) :
                                    $code=$row['code_number'];
            endwhile;
            
             $update=$con->prepare("UPDATE `jw_regestered_jobs` SET `sure_id`=1,error_state=0 WHERE jr_id=$id");
               if($update->execute()){
            header('location:userjob.php');  
             exit();      
              }
        }else{
        echo "not found";
        }
}elseif(isset($_POST['delcode'])){
$id= $_POST['id'];
$uid= $_POST['userid'];
$jid= $_POST['jobid'];
           $GLOBALS['query']="SELECT * FROM `jw_regestered_jobs` where jr_id=$id and job_id=$jid and user_id=$uid";
$h_display_item=$con->prepare($GLOBALS['query']);
    $h_display_item->execute();
    $h_empty= $h_display_item->rowcount();

        if($h_empty==1){
                                   while($row=$h_display_item->fetch()) :
                                    $code=$row['code_number'];
            endwhile;
            
             $update=$con->prepare("UPDATE `jw_regestered_jobs` SET `sure_id`=0,code_number=null,error_state=0 WHERE jr_id=$id");
               if($update->execute()){
            header('location:userjob.php');  
             exit();      
              }
        }else{
        echo "not found";
        }
}elseif(isset($_POST['editcode'])){
$id= $_POST['id'];
$uid= $_POST['userid'];
$jid= $_POST['jobid'];
           $GLOBALS['query']="SELECT * FROM `jw_regestered_jobs` where jr_id=$id and job_id=$jid and user_id=$uid";
$h_display_item=$con->prepare($GLOBALS['query']);
    $h_display_item->execute();
    $h_empty= $h_display_item->rowcount();

        if($h_empty==1){
                                   while($row=$h_display_item->fetch()) :
                                    $code=$row['code_number'];
            endwhile;
            
             $update=$con->prepare("UPDATE `jw_regestered_jobs` SET `sure_id`=0,code_number=null,error_state=1 WHERE jr_id=$id");
               if($update->execute()){
            header('location:userjob.php');  
             exit();      
              }
        }else{
        echo "not found";
        }
    }
}

        ?>