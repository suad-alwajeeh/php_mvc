<?php
ob_start();
session_start();
if(isset($_SESSION['username'])){
}else{
header('location:index.php');
exit();
}
include '../db_con/db_con.php';
?>
<?php include 'header.php'; ?>
<?php include 'nav.php'; ?>
  

   <!--add form-->
   <section class="header " >
    <div class="container-fluid">
        <div class="row">
            <div class=" col-sm-12">
                <h4 class="text-center text-black">بيانات عامه عن المسجل</h4>
             </div>
             <div class="col-1"></div>
             <div class="col-10">
                 <table class="table table-bordered text-right" style="direction:rtl;">
    <thead class="thead-light">
      <tr>
          <th>الاسم</th>
        <th>المحتوى</th>
      </tr>
    </thead>
    <tbody>
               <?php
if(isset($_GET['id'])){
$id=$_GET['id'];
    $GLOBALS['id']=$id;
   $GLOBALS['query']="SELECT * FROM `jw_users` where id=$id";
$h_display_item=$con->prepare($GLOBALS['query']);
    $h_display_item->execute();
    $h_empty= $h_display_item->rowcount();

?>
                 <?php while($row=$h_display_item->fetch()) :

           echo'
      <tr>
        <td>الاسم الثلاثي</td>
        <td>'.$row['fullname'].'</td>   
  
      </tr>
       <tr>
        <td>  تاريخ الميلاد</td>
        <td>'.$row['birthdate'].'</td>   
  
      </tr> 
      <td> مكان الميلاد</td>
        <td>'.$row['birthplace'].'</td>   
  
      </tr>
       <tr>
        <td> الحالة الاجتماعية</td>
        <td>'.$row['social'].'</td>   
  
      </tr>
       <tr>
        <td>رقم الواتساب</td>
        <td>'.$row['whatsapp'].'</td>   
  
      </tr>
       <tr>
        <td>المدينة</td>
        <td>'.$row['city'].'</td>   
  
      </tr>
       <tr>
        <td>المكان الذي تعيش فيه</td>
        <td>'.$row['placeoflife'].'</td>   
  
      </tr>
       <tr>
        <td>الشارع</td>
        <td>'.$row['street'].'</td>   
  
      </tr>
       <tr>
        <td>الحي</td>
        <td>'.$row['district'].'</td>   
  
      </tr>
       <tr>
        <td>رقم المبنى</td>
        <td>'.$row['buldingnumber'].'</td>   
  
      </tr>
       <tr>
        <td>الرمز البريدي</td>
        <td>'.$row['zipcode'].'</td>   
  
      </tr>
       <tr>
        <td>الرمز الاضافي</td>
        <td>'.$row['additonalcode'].'</td>   
  
      </tr>
       <tr>
        <td>رقم الوحدة</td>
        <td>'.$row['statenumber'].'</td>   
  
      </tr>
       <tr>
        <td>وظيفة حالية او سابقة</td>
        <td>'.$row['job'].'</td>   
  
      </tr>
       <tr>
        <td>جهة العمل</td>
        <td>'.$row['jopplace'].'</td>   
  
      </tr>
      ';
endwhile;}
?>
    </tbody>
  </table>
     <a href="users.php" style="float: ;width: 100%;"  class=" btn btn-dark">عودة</a> 
                 </div> 
             <div class="col-1"></div>  
        </div>
    </div>
</section>
<!--add form-->
<?php
ob_end_flush();
?>