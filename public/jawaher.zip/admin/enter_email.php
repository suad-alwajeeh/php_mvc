<?php
ob_start();
session_start();
if(isset($_SESSION['username'])){
//echo 'welcome  '.$_SESSION['username'];
}else{
header('location:index.php');
exit();
}
include '../db_con/db_con.php';
?>
<?php include 'header.php'; ?>

   <!--start login-->
        <section class="login">
            <div class="container">
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8 ">
                        <div class="log">
                            <h3 class="text-right">
لتغيير كلمة المرور ادخل الايميل الخاص بك                                </br>
                                </h3>
                           <?php

if($_SERVER['REQUEST_METHOD']=='POST'){
$email=$_POST['email'];
    $sqlq=$con->prepare("select email from jw_user where email=?");
    $sqlq->execute(array($email));
    $cou=$sqlq->rowCount();

if($cou > 0){
     $head='to '.$email;
       $message='https://almohittarabii.000webhostapp.com/rowad/cpanal/new_pass.php لاعادة تعيين كلمة المرور ادخل على الرابط ';
         mail($email,'اعادة تعيين كلمة المرور',$message,$head);
        
                $success='<div class="alert alert-success" style="text-align:center;">"^-^Thank you^_^"</div>';
    echo $success;
header('location:message.php');
    exit();
}elseif($cou <= 0){
     
 $success='<div class="alert alert-danger" style="text-align:center;">تأكد من كتابة الايميل بشكل صحيح</div>';
    echo $success;
}
};
?>
                        <form class="form text-right" action="<?php echo $_SERVER['PHP_SELF']?>"  method="POST">
                         <div class="form-group">
                          <input name="email"   autocomplete="off" type="email" class="text-right form-control" placeholder="الايميل" >
                        </div>
                        
                          <div class="form-group">
                            <button type="submit" name="submit" class="btn btn-outline-dark" style="width:100%">ارسال</button>
                          </div>
                          </form>
                          </div>
                    </div>
                    <div class="col-md-2"></div>
                </div>    
            </div>
        </section>

   <!--start login-->

   </body>
   </html>
<?php
ob_end_flush();
?>