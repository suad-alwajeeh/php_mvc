<?php
ob_start();
session_start();
if(isset($_SESSION['username'])){
//echo 'welcome  '.$_SESSION['username'];
}else{
header('location:index.php');
exit();
}
include '../db_con/db_con.php';
?>
</br>
</br>
</br>
<?php
if(isset($_GET['id'])){
$id=$_GET['id'];
		$pro_fetch=$con->prepare("select * from jw_jobs where id='$id'");
		$pro_fetch->setFetchMode(PDO:: FETCH_ASSOC);
		$pro_fetch->execute();
        $cou=$pro_fetch->rowCount();
    
    if($cou > 0){  
         $proy_fetch=$con->prepare("DELETE FROM `jw_jobs` WHERE id='$id'");
		if($proy_fetch->execute()){
            	$pro_fetch=$con->prepare("select * from jw_regestered_jobs where job_id='$id'");
		$pro_fetch->setFetchMode(PDO:: FETCH_ASSOC);
		$pro_fetch->execute();
        $cou=$pro_fetch->rowCount();
    if($cou > 0){ 
          $proy_fetch=$con->prepare("DELETE FROM `jw_regestered_jobs` WHERE job_id='$id'");
		if($proy_fetch->execute()){
         header('location:dashboard.php');  
             exit(); 
        }
       
    }
            
        }         
    }
}


?>
<?php
ob_end_flush();
?>