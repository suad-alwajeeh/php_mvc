<?php include 'header.php'; ?>
  <?php include 'nav.php'; ?>
  <?php include '../db_con/function.php'; ?>


  <?php include"operation.php";?>

   
    <!--start control-->
    <section class="control bg-light" >
        <div class="container-fluid">
            <div class="row">
<div class="col-12">
<table class="table table-bordered text-center" style="direction:rtl;">
<thead class="thead-light">
<tr>
  <th>#</th>
  <th> اسم المقدم</th>
  <th>اسم الوظيفة </th>
  <th> رقم المقدم  </th>
  <th>  ارسال الكود واتساب </th>
</tr>
</thead>
    
<tbody>
    <?php
     $GLOBALS['query']="select jw_regestered_jobs.jr_id,jw_regestered_jobs.code_number,jw_regestered_jobs.dateofregister,jw_regestered_jobs.job_id,jw_regestered_jobs.user_id,jw_jobs.name,jw_users.fullname,jw_users.whatsapp,jw_users.id FROM jw_regestered_jobs JOIN jw_jobs on jw_jobs.id=jw_regestered_jobs.job_id JOIN jw_users on jw_users.id=jw_regestered_jobs.user_id ";
$h_display_item=$con->prepare($GLOBALS['query']);
    $h_display_item->execute();
    $h_empty= $h_display_item->rowcount();

               while($row=$h_display_item->fetch()) :
echo'
<tr>
<td>'.$row['id'].'</td>
<td>'.$row['fullname'].'</td>
<td> '.$row['name'].'</td>
<td> '.$row['whatsapp'].' </td>
<td>';?><?php //echo check_code_state($row['jr_id']); ?><?php echo '</td>
<td> ';?><?php echo  check_code_send_state($row['jr_id'],$row['job_id'],$row['user_id']); ?><?php echo ' </td>
<td> '.$row['dateofregister'].' </td>
</tr>';

endwhile;
    ?>
</tbody>
</table>
</div>
</div>
</div>
            
</section>
<!--end control-->
   </body>
   </html>