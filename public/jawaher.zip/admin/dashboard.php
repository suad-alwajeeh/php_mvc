<?php
ob_start();
session_start();
if(isset($_SESSION['username'])){
//echo 'welcome  '.$_SESSION['username'];
}else{
header('location:index.php');
exit();
}
include '../db_con/db_con.php';
?>
<?php include 'header.php'; ?>
  <?php include 'nav.php'; ?>
<?php include"operation.php";?>
  
   
    <!--start control-->
    <section class="control bg-light" >
        <div class="container-fluid">
            <div class="row">
<div class="col-12">
<table class="table table-bordered text-center" style="direction:rtl;">
<thead class="thead-light">
<tr>
  <th>#</th>
  <th> اسم الوظيفة</th>
  <th> اسم الجهة</th>
  <th>تاريخ النشر</th>
  <th> العمليات</th>
</tr>
</thead>
<tbody>
     <?php 
   $GLOBALS['query']="SELECT * FROM `jw_jobs` ORDER BY id DESC ";
$h_display_item=$con->prepare($GLOBALS['query']);
    $h_display_item->execute();
    $h_empty= $h_display_item->rowcount();

?>
                 <?php while($row=$h_display_item->fetch()) :

           echo'
<tr>
<td>'.$row['id'].'</td>
<td>'.$row['name'].'</td>
<td>'.$row['jeha'].'</td>
<td>  3-10-2020 </td>
<td>      
<div class="btn-group mr-2 text-center" role="group" aria-label="Second group">
<a href="edit?id='.$row['id'].'"" style="border-radius: 0px;" type="button" class="btn btn-outline-success">
<span class="ion-edit"></span></a>
<a href="delete?id='.$row['id'].'" style="border-radius: 0px;" type="button" class="btn btn-outline-danger">
<span class="ion-android-delete"></span></a>
</div>
  </td>
</tr>
';
endwhile;
?>

</tbody>
</table>
</div>
</div>
</div>
</section>
<!--end control-->
   </body>
   </html>
<?php
ob_end_flush();
?>
