<?php include 'header.php'; ?>

   <!--start login-->
        <section class="login">
            <div class="container">
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8 ">
                        <div class="log">
                            <h4 class="text-right">
                                الرجاء تفقد ايميلك لتتمكن من تغيير كلمة المرور بشكل صحيح
                                </h4>
                      
                          </div>
                    </div>
                    <div class="col-md-2"></div>
                </div>    
            </div>
        </section>

   <!--start login-->

   </body>
   </html>