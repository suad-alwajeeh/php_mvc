<?php
ob_start();
error_reporting(0);
ini_set('display_errors', 0);
session_start();
if(isset($_SESSION['username'])){
header('location:dashboard.php');
}
include"../db_con/db_con.php";

if($_SERVER['REQUEST_METHOD']=='POST'){
$username=$_POST['name'];
$password=$_POST['password'];
$hashpassword= sha1($password);
    $sqlq=$con->prepare("select name,password from jw_user where name=? AND password=?");
    $sqlq->execute(array($username,$hashpassword));
    $cou=$sqlq->rowCount();

if($cou > 0){
       echo $username;
   $_SESSION['username']=$username;
 header('location:dashboard.php');
exit();
}
};
?>
<?php include 'header.php'; ?>
   <!--start login-->
        <section class="login">
            <div class="container">
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8 ">
                        <div class="log">
                            <h3 class="text-right">
تسجيل الدخول 
                                </br>
                                </h3>
                        <form class="form text-right" action="<?php echo $_SERVER['PHP_SELF']?>"  method="POST" >
                         <div class="form-group">
                          <input type="text" name="name"  autocomplete="off" class="text-right form-control" placeholder="الاسم" >
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" class=" text-right form-control" placeholder="كلمة المرور" >
                          </div>
                          <div class="form-group">
                              <a  class=" btn-outline-danger" href="enter_email.php">نسيت كلمة المرور</a>
                             <button type="submit" name="submit" class="btn btn-outline-dark">دخول</button>
                          </div>
                          </form>
                          </div>
                    </div>
                    <div class="col-md-2"></div>
                </div>    
            </div>
        </section>

   <!--start login-->

   </body>
   </html>
<?php
ob_end_flush();
?>
