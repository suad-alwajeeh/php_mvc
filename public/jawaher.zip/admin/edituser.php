<?php
ob_start();
session_start();
if(isset($_SESSION['username'])){
}else{
header('location:index.php');
exit();
}
include '../db_con/db_con.php';
?>
<?php include 'header.php'; ?>
<?php include 'nav.php'; ?>


   <!--add form-->
   <section class="header " >
    <div class="container-fluid">
        <div class="row">
            <div class=" col-sm-12">
                <h4 class="text-center text-black">تعديل مستخدم</h4>
             </div>
             <div class="col-1"></div>
             <div class="col-10">
<?php
 $do = isset($_GET['do']);

if($do == 'edit'){
    if(isset($_POST['next'])){
$id= $_POST['id'];
 $name= $_POST['name'];    
$email= $_POST['email'];    
$pass= $_POST['pass'];   
 $text= str_replace("'", "\'", $name);        
        $text2= str_replace("'", "\'", $email);
         $text3= str_replace("'", "\'", $pass);        
$hashpassword= sha1($pass);
        if($pass != null ){  
            $update=$con->prepare("UPDATE `jw_user` SET `name`='$text',`email`='$text2',`password`='$hashpassword' ,`con_password`='$text3' where id='$id' ");
               if($update->execute()){
                    header('location:edituser.php?id='.$id);
        exit();
              }
     }else{
         
            
 $success='<div class="alert alert-danger" style="text-align:center;">"يجب ان تدخل كلمة السر"</div>';
    echo $success;
        }
    }
    }
?>
                  <?php
if(isset($_GET['id'])){
$id=$_GET['id'];
    $GLOBALS['id']=$id;
		$pro_fetch=$con->prepare("select * from jw_user where id=$id ");
		$pro_fetch->setFetchMode(PDO:: FETCH_ASSOC);
		$pro_fetch->execute();
        $cou=$pro_fetch->rowCount();
    
    if($cou > 0){ ?> 
                    <form action="?do=edit"  method="POST" class="text-right">
                    <div class="form-group">
                        
                          <?php while($row=$pro_fetch->fetch()) :?>
                                <input type="text" name="id" hidden="hidden" value="<?php echo $row['id'] ;?>" 
                                       class="form-control  rounded-0 p-3" style="height: 55px;"  placeholder="الاسم"> 
                        <label for=""> الاسم</label>
                        <input type="text" required  value="<?php echo $row['name'] ;?>"
                            class="form-control" name="name" id="" >
                        </div>
                         <div class="form-group">
                        <label for=""> كلمة المرور</label>
                        <input type="text" required  value="<?php echo $row['con_password'] ;?>"
                            class="form-control" name="pass" id="" >
                        </div>
                         <div class="form-group">
                        <label for="">  الايميل</label>
                        <input type="email" required  value="<?php echo $row['email'] ;?>"
                            class="form-control" name="email" id="" >
                        </div>
                         <?php endwhile; }}?>
                        <div class="form-group">
                        <button type="submit" name="next" style="width: 49%;" class="btn btn-dark">موافق</button>
                            <a href="user.php" style="float: left;width: 49%;"  class=" btn btn-dark">عودة</a>
                            </div>
                 </form>
             </div> 
             <div class="col-1"></div>  
        </div>
    </div>
</section>
<!--add form-->

<?php
ob_end_flush();
?>