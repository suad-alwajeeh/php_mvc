 <!--start header-->
   <section class="header bg-dark" >
    <div class="container-fluid">
        <div class="row" style="direction:rtl">
            <div class="col-6">
                <h4 class="text-right text-white-50"> جواهر للتوظيف</h4>
             </div>
            <div class="col-6">
                <h6 class="text-left"> <a class="text-light " href="user.php"> تعديل مستخدم </a>
                    <a class="text-light " href="logout.php">خروج </a></h6>
             </div>   
        </div>
    </div>
</section>
<!--end header-->