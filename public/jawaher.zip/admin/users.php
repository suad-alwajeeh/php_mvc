<?php
ob_start();
session_start();
if(isset($_SESSION['username'])){
//echo 'welcome  '.$_SESSION['username'];
}else{
header('location:index.php');
exit();
}
include '../db_con/db_con.php';
?>
<?php include 'header.php'; ?>
  <?php include 'nav.php'; ?>

  <?php include"operation.php";?>

   
    <!--start control-->
    <section class="control bg-light" >
        <div class="container-fluid">
            <div class="row">
<div class="col-12">
<table class="table table-bordered text-center" style="direction:rtl;">
<thead class="thead-light">
<tr>
  <th>#</th>
  <th> الاسم</th>
  <th>المدينة </th>
  <th> واتساب</th>
  <th> العمليات</th>
</tr>
</thead>
<tbody>
 <?php 
   $GLOBALS['query']="SELECT * FROM `jw_users` ORDER BY id DESC ";
$h_display_item=$con->prepare($GLOBALS['query']);
    $h_display_item->execute();
    $h_empty= $h_display_item->rowcount();

?>
                 <?php while($row=$h_display_item->fetch()) :

           echo'
<tr>
<td>'.$row['id'].'</td>
<td>'.$row['fullname'].'</td>
<td>'.$row['city'].'</td>
<td><a class="text-dark" href="https://api.whatsapp.com/send?phone='.$row['whatsapp'].'?text=put the message text here" target="_blank"><i class="ion-social-whatsapp-outline text-success display-8"></i>'.$row['whatsapp'].'</i></a></td>
<td>      
<div class="btn-group mr-2 text-center" role="group" aria-label="Second group">
<a href="view.php?id='.$row['id'].'" style="border-radius: 0px;" type="button" class="btn btn-outline-success">
<span class="ion-eye"></span></a>
</div>
  </td>
</tr>';
endwhile;
?>
</tbody>
</table>
</div>
</div>
</div>
</section>
<!--end control-->
   </body>
   </html>