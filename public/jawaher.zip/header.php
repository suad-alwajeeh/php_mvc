<?php
ob_start();
error_reporting(0);
ini_set('display_errors', 0);
session_start();
if(isset($_SESSION['n']) && isset($_SESSION['id'])){   
echo $_SESSION['n'];
    echo $_SESSION['id'];
}
?>
<?php 
include 'db_con/db_con.php'; 
include 'db_con/function.php';
?>
<?php
ob_start();
if($_SERVER['REQUEST_METHOD']=='POST'){

    if(isset($_POST['login'])){

$username=$_POST['usern'];
$password=$_POST['pass'];
$hashpassword= sha1($password);
    $sqlq=$con->prepare("select id,user_name,user_pass from jw_users where user_name=? AND user_pass=?");
    $sqlq->execute(array($username,$hashpassword));
    $cou=$sqlq->rowCount();
if($cou == 1){
    while($row=$sqlq->fetch()) :
    $GLOBALS['id']= $row['id'];
        $_SESSION['n']=$username;
    $_SESSION['id']=$row['id'];
endwhile;
     header('location:jobs.php');  
             exit();
}
else{
echo check_login_erorr(0);

}
    }
}

;
?>
<!DOCTYPE html>
<html lang="en">
   <head>
       
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>جواهر للتوظيف</title>
      <link href="custom/font/f/Tajawal-Medium.ttf" rel="stylesheet"> 
      <link rel="stylesheet" href="custom/font/ionicons/css/ionicons.min.css">
      <link rel="stylesheet" href="custom/css/bootstrap-datetimepicker.css?v2">
      <link rel="stylesheet" href="custom/css/bootstrap.min.css">
      <link rel="stylesheet" href="custom/css/style.css">
      <link rel="stylesheet" href="custom/css/response.css">
       
      </head>
   <body>
   <!--start header-->
 
   <nav class="fixed-top">
    <div class="menu-icon">
          <span class="ion-android-list "></span></div>
          <div class="logo">
          جواهر</div>
          <div class="nav-items">
          <li><a href="index.php">الرئيسية</a></li>
          <li><a href="jobs.php">الوظائف</a></li>
          <li><a href="contact.php">تواصل معنا</a></li>
          <li id="log1"><a  href="signup.php"> انشاء حساب</a></li>
          <li id="log"><a  data-toggle="modal" data-target="#myModal1">تسجيل الدخول</a></li>
              <li id="logg"><a  style="float: right;">اهلا<?php echo $_SESSION['n'];?>  </a> </li>
          <li id="logg1"><a data-toggle="modal" data-target="#myModali" > التوثيق</a></li>
            <li id="logg2"> <a  href="myjobs.php?id=<?php echo $_SESSION['id'];?>">حسابي</a></li>
              <?php
                if(isset($_SESSION['n'])&&!empty($_SESSION['n'])){?>
               <script type="text/JavaScript">  
                  document.getElementById("log").style.display="none";
                  document.getElementById("log1").style.display="none";
                  document.getElementById("logg").style.display="block";
                  document.getElementById("logg1").style.display="block";
                  document.getElementById("logg2").style.display="block";
                  console.log("user name or passwors is error");
               </script> 
                <?php }elseif(!isset($_SESSION['n'])&& empty($_SESSION['n'])){
                    echo'   <script type="text/JavaScript">  
                  document.getElementById("log").style.display="block";
                  document.getElementById("log1").style.display="block";
                  document.getElementById("logg").style.display="none";
                  document.getElementById("logg1").style.display="none";
                  document.getElementById("logg2").style.display="none";
                  console.log("user name or passwors is error");
               </script> ';
} 
         ?>
      </div>

      <div class="search-icon">
      <span class="ion-android-search"></span></div>
      <div class="cancel-icon">
      <span class="ion-close"></span></div>
      <form action="search.php" method="post">
      <input type="search" name="key" class="search-data" placeholder="Search" required>
      <button type="submit" name="search" class="ion-android-search"></button>
      </form>
</nav>
       <?php
if(!empty($_SESSION['id'])){
 echo check_user_job($_SESSION['id']);
}
?>
<script>
  const menuBtn = document.querySelector(".menu-icon span");
  const searchBtn = document.querySelector(".search-icon");
  const cancelBtn = document.querySelector(".cancel-icon");
  const items = document.querySelector(".nav-items");
  const form = document.querySelector("form");
  menuBtn.onclick = ()=>{
    items.classList.add("active");
    menuBtn.classList.add("hide");
    searchBtn.classList.add("hide");
    cancelBtn.classList.add("show");
  }
  cancelBtn.onclick = ()=>{
    items.classList.remove("active");
    menuBtn.classList.remove("hide");
    searchBtn.classList.remove("hide");
    cancelBtn.classList.remove("show");
    form.classList.remove("active");
    cancelBtn.style.color = "#ff3d00";
  }
  searchBtn.onclick = ()=>{
    form.classList.add("active");
    searchBtn.classList.add("hide");
    cancelBtn.classList.add("show");
  }
</script>
   <!--end header-->
       
       <!-- The signup Modal -->
<div class="modal" id="myModal1">
  <div class="modal-dialog">
    <div class="modal-content" style="color: #402558;">

      <!-- Modal Header -->
      <div class="modal-header" style="direction: rtl;">
        <h4 class="modal-title color-white text-center">تسجيل الدخول </h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
 <form  class="text-right" role="form" action="<?php echo $_SERVER['PHP_SELF']?>"  method="POST"  >
                      <div class="form-group col-sm-12" style="float:right;">                                                                                        <label>اسم المستخدم </label>

                        <input type="text" name="usern" value="<?php if(isset($_POST['usern'])){echo $_POST['usern'];}?>" class="form-control  rounded-0 p-3"   placeholder="">   
                      </div>
                         <div class="form-group col-sm-12" style="float:right;"> 
                             <label> كلمة المرور </label>

                        <input type="password" name="pass" value="<?php if(isset($_POST['pass'])){echo $_POST['pass'];}?>" class="form-control  rounded-0 p-3" placeholder=" ">   
                      </div>   
      <div class="form-group  col-sm-12" style="float:right;"> 
                      <button type="submit" name="login" style="width: 49%;color:#402558; border: 1px solid #402558;float:right;" class="btn p-2 rounded-0" >دخول</button>
                         <a data-dismiss="modal" style="width:49%;border: 1px solid #402558;color:#402558;float:left;" class="btn rounded-0 p-2" href="#">الغاء</a>
                     </div>
                    </form></div>

     
    </div>
  </div>
</div>
              <!--end The signup Modal -->
       
  
   
       <!-- The signup Modal -->
<div class="modal" id="myModal23">
  <div class="modal-dialog">
    <div class="modal-content" style="color: #402558;">

      <!-- Modal Header -->
      <div class="modal-header" style="direction: rtl;">
        <h4 class="modal-title color-white text-center">كود التوثيق </h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
                  <p class="modal-title color-white text-center">لتتمكن من الدخول في القرعة ,يرجى توثيق حسابك </p>

 <form  class="text-right" role="form" action="?do=code"  method="POST"  >
                     
                         <div class="form-group col-sm-12" style="float:right;"> 
                             <label> : كود التوثيق </label>
                         <input type="number" hidden="hidden" name="userid" value="<?php echo $_SESSION['id'];?>" class="form-control  rounded-0 p-3" placeholder=" ">   
                        <input type="number" name="codenum" value="" class="form-control  rounded-0 p-3" placeholder=" ">   
                      </div>   
      <div class="form-group  col-sm-12" style="float:right;"> 
                      <button type="submit" name="CODEIN" style="width: 98%;color:#402558; border: 1px solid #402558;float:right;" class="btn p-2 rounded-0" >توثيق</button>
                         
                     </div>
                    </form></div>

     
    </div>
  </div>
</div>
              <!--end The signup Modal -->
          
             <!-- The signup Modal -->
<div class="modal" id="myModali">
  <div class="modal-dialog">
    <div class="modal-content" style="color: #402558;">

      <!-- Modal Header -->
      <div class="modal-header" style="direction: rtl;">
        <h4 class="modal-title color-white text-center"> توثيق الحساب عبر جواهر </h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>

      </div>
 
      <!-- Modal body -->
      <div class="modal-body">
                            <p class="modal-title color-white text-center">لتتمكن من الدخول في القرعة ,يرجى توثيق حسابك </p>
           <?php
if(!empty($_SESSION['id'])){
$id=$_SESSION['id'];
		$pro_fetch=$con->prepare("select * from jw_users where id=$id ");
		$pro_fetch->setFetchMode(PDO:: FETCH_ASSOC);
		$pro_fetch->execute();
        $cou=$pro_fetch->rowCount();
    
    if($cou ==1){ ?>
       
     <?php  while($row=$pro_fetch->fetch()) : ?>
                      <div class="form-group col-sm-12 text-right" style="float:;">                                                                                        <label>رقم الهوية</label>
                <input type="text" name="card" readonly value="<?php echo $row['card'] ;?>" class="form-control text-right  rounded-0 p-3">  
                      </div>
                         <div class="form-group col-sm-12 text-right" style="float:;"> 
                             <label>تاريخ الميلاد</label>
     <input type="text" readonly name="birthdate" value="<?php echo $row['birthdate'] ;?>" class="form-control text-right  rounded-0 p-3">   
                      </div> 
     <?php endwhile;}} ?>
      <div class="form-group  col-sm-12 " style="float:right;"> 
 <button  data-toggle="modal" data-target="#myModal23" style="width: 98%;color:#402558; border: 1px solid #402558;float:right;" class="btn p-2 rounded-0 close"  class="close" data-dismiss="modal">التالي</button>
                     </div>
        </div>

     
    </div>
  </div>
</div>   
       
<?php
 $do = isset($_GET['do']);
if($do == 'code'){
    if(isset($_POST['CODEIN'])){
$id= $_POST['userid'];
$code= $_POST['codenum'];
           $GLOBALS['query']="SELECT * FROM `jw_regestered_jobs` where user_id=$id " ;
$h_display_item=$con->prepare($GLOBALS['query']);
    $h_display_item->execute();
    $h_empty= $h_display_item->rowcount();
        if($h_empty >= 1){
             while($row=$h_display_item->fetch()) :
    $GLOBALS['jidd']= $row['job_id'];
endwhile;
           $op= $GLOBALS['jidd'];
     $GLOBALS['query']="UPDATE `jw_regestered_jobs` SET `code_number`=$code WHERE user_id=$id" ;
$h_display_item1=$con->prepare($GLOBALS['query']);
    $h_display_item1->execute();     
                  header('location:index.php');
            exit();
              }else{
 $success='<section class=" error_m">
<div class="alert alert-danger" style="text-align:center;"> ..  الرمز الذي تم ادخاله خاطئ..</div></section>';
    echo $success;  
           header('location:index.php');
            exit();}
        }
    }

       ?>
     
<?php
 $do = isset($_GET['do']);
if($do == 'sure'){
    if(isset($_POST['sure'])){
$uid= $_POST['usid'];
$un= $_POST['user'];
        $jid= $_POST['jobid'];
$jn= $_POST['jobname'];
      
            $GLOBALS['query']="INSERT INTO `jw_regestered_jobs`(`job_id`, `user_id`, `code_number`, `dateofregister`, `sure_id`) VALUES ('$jid','$uid',null,NOW(),'0')" ;
$h_display_item1=$con->prepare($GLOBALS['query']);
   if( $h_display_item1->execute()){
header('location:index.php'); 
   exit();
   }else{
 $success='<section class=" error_m">
<div class="alert alert-danger" style="text-align:center;"> ..  الرمز الذي تم ادخاله خاطئ..</div></section>';
    echo $success;        }
        }
    }

       ?>
