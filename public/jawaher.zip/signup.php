<?php include 'header.php'; ?> 

</br>
</br></br>
</br>
<section class="reg" id="register">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="text-center" style="color: #402558;">أنشاء حساب</h3>
                                <h6 class="text-center" style="color: #402558;">
                                  !! يرجى ادخال البيانات الصحيحة حتى لايتم رفض طلبك
                </h6>
</br>
</br>

<?php
        $do = isset($_GET['do']);
if($do == 'add'){
    if(isset($_POST['addbtn'])){
 $fname= $_POST['name'];
$bd= $_POST['birthday'];
$bp= $_POST['birthplace'];
$card= $_POST['card'];
$type= $_POST['type'];
 $social= $_POST['social'];
$whatsapp= $_POST['whatsapp'];
$city= $_POST['city'];
$place= $_POST['place'];    
$street= $_POST['street'];       
$hi= $_POST['hi'];       
$code1= $_POST['code1'];       
$code2= $_POST['code2'];       
$point= $_POST['point'];       
$build= $_POST['build'];       
$job= $_POST['job'];       
$job1= $_POST['job1'];       
$usern= $_POST['usern'];       
$pass= $_POST['pass'];       
    $form_error = array();
    
     if(strlen($fname)<3){
    $form_error[]='user first name must be more than 3 chars';
    }else if(strlen($whatsapp)>12){
    $form_error[]='whatsapp number must have country code as 966  and the phone number';
    }else if(strlen($whatsapp)<12){
    $form_error[]='whatsapp number must have country code as 966  and the phone number';
    }else if(strlen($usern)<3){
    $form_error[]='user name is short you must enter more than 3 char';
    }else if(strlen($pass)<1){
    $form_error[]='you must enter pass';
    }
    if(empty($form_error)){
          $hashpassword= sha1($pass);
          $insert_into_ckeckout=$con->prepare("INSERT INTO `jw_users`(`fullname`, `birthdate`, `birthplace`, `social`,`card`, `card_type`, `whatsapp`,  `city`, `placeoflife`, `street`, `district`, `buldingnumber`, `zipcode`, `additonalcode`, `statenumber`, `job`, `jopplace`, `user_name`, `user_pass`)VALUES ('$fname','$bd','$bp','$social','$card','$city','$whatsapp','$type','$place','$street','$hi','$build','$code1','$code2','$point','$job','$job1','$usern','$hashpassword')");
              if($insert_into_ckeckout->execute()){
          
                $success='<div class="alert alert-success" style="text-align:center;">"^-^قد تم انشاء حسابك بشكل صحيح اذا اردت تسجيل الدخول <a id="log" data-toggle="modal" style="border-bottom: 1px solid gray;cursor: pointer;" data-target="#myModal1">اضغط هنا</a> ^_^ "</div>';
    }
    }
    
}
}

?>     
            </div>
            <div class="col-12">
                <div class="error" style="color:red;">
                    <?php 
                 if(isset($form_error)){
                    foreach($form_error as $error) {
                       echo $error.'<br/>';
                    }}
                    ?></div>
                  <?php 
                 if(isset($success)){
                   echo $success;}
                    ?>
                 <form  class="text-right" role="form" action="?do=add"  method="POST">
                      <div class="form-group col-md-4 col-sm-12" style="float:right;">                                                                                        <label>  الأسم الثلاثي </label>

                        <input type="text" name="name" value="<?php if(isset($_POST['name'])){echo $_POST['name'];}?>" class="form-control  rounded-0 p-3"   placeholder="">   
                      </div>
                         <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                             <label>   تاريخ الميلاد </label>
                        <input type="text" name="birthday" value="<?php if(isset($_POST['birthday'])){echo $_POST['birthday'];}?>" class="form-control hijri-date-default  rounded-0 p-3" placeholder=" ">   
                      </div>
                        <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                         <label>  مكان الميلاد </label>

                        <input type="text" name="birthplace" value="<?php if(isset($_POST['birthplace'])){echo $_POST['birthplace'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                         <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                        <label> الحالة الاجتماعية </label>

                        <input type="text" name="social" value="<?php if(isset($_POST['social'])){echo $_POST['social'];}?>" class="form-control  rounded-0 p-3"  placeholder="">   
                      </div>
                      <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                        <label>  رقم الهوية </label>

                        <input type="text" name="card" value="<?php if(isset($_POST['card'])){echo $_POST['card'];}?>" class="form-control  rounded-0 p-3"  placeholder="">   
                      </div>
                      <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                        <label>  نوع الهوية </label>

                        <input type="text" name="type" value="<?php if(isset($_POST['type'])){echo $_POST['type'];}?>" class="form-control  rounded-0 p-3"  placeholder="">   
                      </div>
                        <div class="form-group col-md-4 col-sm-12" style="float:right;">
                            <label>رقم واتساب للتواصل معكم </label>
 <input type="text" name="whatsapp" value="<?php if(isset($_POST['whatsapp'])){echo $_POST['whatsapp'];}?>" class="form-control  rounded-0 p-3"  placeholder=""> 
                      </div>
                         <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                        <label>المنطقة </label>
                        <input type="text" name="place" value="<?php if(isset($_POST['place'])){echo $_POST['place'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                        <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                             <label> المدينة </label>
                        <input type="text" name="city" value="<?php if(isset($_POST['city'])){echo $_POST['city'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                         <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                             <label>الحي </label>
                        <input type="text" name="hi" value="<?php if(isset($_POST['hi'])){echo $_POST['hi'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                             <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                             <label>الشارع </label>
                        <input type="text" name="street" value="<?php if(isset($_POST['street'])){echo $_POST['street'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                             <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                             <label>الرمز البريدي </label>
                        <input type="text" name="code1" value="<?php if(isset($_POST['code1'])){echo $_POST['code1'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                             <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                             <label>رقم المبنى </label>
                        <input type="text" name="build" value="<?php if(isset($_POST['build'])){echo $_POST['build'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                             <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                             <label>الرمزالاضافي </label>
                        <input type="text" name="code2" value="<?php if(isset($_POST['code2'])){echo $_POST['code2'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                         
                             <div class="form-group col-md-4 col-sm-12" style="float:right;"> 
                             <label>رقم الوحدة </label>
                        <input type="text" name="point" value="<?php if(isset($_POST['point'])){echo $_POST['point'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                      <div class="form-group col-md-6 col-sm-12" style="float:right;"> 
                             <label>وظيفة حالية او سابقة </label>
                        <input type="text" name="job" value="<?php if(isset($_POST['job'])){echo $_POST['job'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                         <div class="form-group col-md-6 col-sm-12" style="float:right;"> 
                             <label> جهة العمل </label>
                        <input type="text" name="job1" value="<?php if(isset($_POST['job1'])){echo $_POST['job1'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                      <div class="form-group col-sm-12" style="float:right;border-top:1px solid #eee"> 
                          </br>
                             <label> البيانات اللازمة لتسجيل الدخول عند الرغبة في التقديم على وظيفة </label>
                     
                      </div>
                      <div class="form-group col-md-6 col-sm-12" style="float:right;"> 
                             <label> اسم المستخدم </label>
                        <input type="text" name="usern" value="<?php if(isset($_POST['usern'])){echo $_POST['usern'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                         <div class="form-group col-md-6 col-sm-12" style="float:right;"> 
                             <label>  كلمة المرور </label>
                        <input type="password" name="pass" value="<?php if(isset($_POST['pass'])){echo $_POST['pass'];}?>" class="form-control  rounded-0 p-3" >   
                      </div>
                     <div class="form-group  col-sm-12" style="float:right;"> 
                      <button type="submit" name="addbtn" style="width: 49%;color:#402558; border: 1px solid #402558;float:right;" class="btn p-2 rounded-0">أرسال</button>
                         <a style="width:49%;border: 1px solid #402558;color:#402558;float:left;" class="btn rounded-0 p-2" href="#">أالغاء</a>
                     </div>
                    </form>
                
            </div>
            
        </div>
    </div>
</section>

</br>
<?php include 'footer.php'; ?> 