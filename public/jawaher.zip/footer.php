<!--================ Start Footer Area =================-->
</br>
</br>
	<footer class="footer-area section-gap">
		<div class="container ">
			<div class="row">
                
				<div class="col-lg-12  col-md-6 col-sm-6" style="direction: rtl;text-align: right;">
					<div class="single-footer-widget">
						<h4 style="">
                            جواهر للوظائف النسائية
                            </br>
                         <span class="fables-title-border color"></span>
                        </h4>
                    </div>
				</div>
				<div class="col-lg-8  col-md-6 col-sm-6" style="direction: rtl;text-align: right;">
					<div class="single-footer-widget">
                        <h6 style="padding: 10px 25px;">
زائرنا العزيز ...
                        اهلا وسهلا بك في موقع جواهر للتوظيف عن بعد الذي يقدم باقة من الوظائف النسائية المتنوعة</h6>
                      
					</div>
				</div>
				
			</div>
        </div>
        	

<script src="custom/js/jquery3.4.1.js"></script>
       <script src="custom/js/bootstrap.min.js"></script>
       <script src="custom/js/script.js"></script>  
<script src="custom/js/bootstrap-hijri-datetimepicker.js?v2"></script>

    <script type="text/javascript">


       $(function () {

            initHijrDatePicker();

            initHijrDatePickerDefault();

            $('.disable-date').hijriDatePicker({

                minDate:"2020-01-01",
                maxDate:"2021-01-01",
                viewMode:"years",
                hijri:true,
                debug:true
            });

        });

        function initHijrDatePicker() {

            $(".hijri-date-input").hijriDatePicker({
                locale: "ar-sa",
                format: "DD-MM-YYYY",
                hijriFormat:"iYYYY-iMM-iDD",
                dayViewHeaderFormat: "MMMM YYYY",
                hijriDayViewHeaderFormat: "iMMMM iYYYY",
                showSwitcher: true,
                allowInputToggle: true,
                showTodayButton: false,
                useCurrent: true,
                isRTL: false,
                viewMode:'months',
                keepOpen: false,
                hijri: false,
                debug: true,
                showClear: true,
                showTodayButton: true,
                showClose: true
            });
        }

        function initHijrDatePickerDefault() {

            $(".hijri-date-default").hijriDatePicker();
        }

    </script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<script>
try {
  fetch(new Request("https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js", { method: 'HEAD', mode: 'no-cors' })).then(function(response) {
    return true;
  }).catch(function(e) {
    var carbonScript = document.createElement("script");
    carbonScript.src = "//cdn.carbonads.com/carbon.js?serve=CK7DKKQU&placement=wwwjqueryscriptnet";
    carbonScript.id = "_carbonads_js";
    document.getElementById("carbon-block").appendChild(carbonScript);
  });
} catch (error) {
  console.log(error);
}
</script>
	</footer>
</body>
</html>
<?php
ob_end_flush();
?>
