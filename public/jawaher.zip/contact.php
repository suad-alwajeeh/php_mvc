<?php include 'header.php'; ?> 

</br>
</br></br>
</br>
<section class="contact">
  <div class="container">
      <div class="row">
      <div class="col-md-6 col-sm-12">
          </br>
</br>
          <img class="" width="100%" src="custom/img/2448111.jpg"/>
      </div> 
       <div class="col-md-6 col-sm-12">
             <div class="">
                <h3 class="text-right" style="color: #402558;"> تواصل معنا</h3>
</br>
</br><div class="error" style="color:red;">
    <?php
                 include 'db_con/db_con.php';
$do = isset($_GET['do']);

if($do == 'add'){
    if(isset($_POST['addbtn'])){
 $username= $_POST['name'];
 $email1= $_POST['email'];
$message1= $_POST['message'];          
          $head1='from'.$email1;   
    if(strlen($username)<3 || $email1==null || $message1==null){
                       echo '<div class="alert alert-danger" style="text-align:center;">"-__-can not send,make sure the name longer than 3 litter and email is correct "</div>';
}else{
        mail('sd.alwajeeh@gmail.com','مكتب جواهر للوظائف النسائية عن بعد  .  صفحة تواصل معنا',$message1,$head1);
                   echo '<div class="alert alert-success" style="text-align:center;">"^-^Thank you^_^"</div>';
    
    }
}
}
                           ?>
    </3>
           <!--Form with header-->
                  <form  class="text-right" role="form" action="?do=add"  method="POST">
                      <div class="form-group col-sm-12" style="float:right;">                                                                                        <label>  الاسم  </label>

                        <input type="text" name="name" value="<?php if(isset($_POST['name'])){echo $_POST['name'];}?>" class="form-control  rounded-0 p-3"   placeholder="">   
                      </div>
                         <div class="form-group col-sm-12" style="float:right;"> 
                             <label> الايميل</label>

                        <input type="email"  name="email" class="form-control  rounded-0 p-3" value="<?php if(isset($_POST['email'])){echo $_POST['email'];}?>" placeholder=" ">   
                      </div>
                      
                       <div class="form-group col-sm-12" style="float:right;"> 
                         <label>   الرسالة </label>
                    <textarea type="text" class="form-control"  name="message" >
                        <?php if(isset($_POST['message'])){echo $_POST['message'];}?>
                           </textarea>
                      </div>
                        <div class="text-center">
                            <input id="send" type="submit" name="addbtn" value="send" class="btn so rounded-0 py-2">
                                  </div>
          </form>
                      <!--Form with header-->
                
            </div>
      </div>
</div>
    </div>
</section>
</br>
</br>
<?php include 'footer.php'; ?> 
