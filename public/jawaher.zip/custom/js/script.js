
function contactus(){
const gobtn=document.getElementById('send');
 gobtn.addEventListener("click",(e)=>{
    document.getElementById("tell").innerHTML="thanks^^";
console.log("okkkkkkkkkkkkkkkkkkk");
 })
}