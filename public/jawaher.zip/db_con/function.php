    <?php
    include'db_con.php';
    function generate_num(){
    $num= rand(1000,9999);
        return $num;
    }

    
    function check_code_state($id){
            global $con;
       $GLOBALS['query']="SELECT * FROM `jw_regestered_jobs` where jr_id= $id";
    $h_display_item=$con->prepare($GLOBALS['query']);
        $h_display_item->execute();
        $h_empty= $h_display_item->rowcount();

                   while($row=$h_display_item->fetch()) :

               if($row['code_number']==null)
     echo'<form action="deal.php?do=gen" method="post">
                <input type="text" name="code" value="'. generate_num().'"  hidden="hidden">
                <input name="id" value="'.$row['jr_id'].'" type="text"  hidden="hidden">
            <button type="submit" name="generate" class="btn btn-warning">توليد الكود</button>
            </form>';
        else 
            echo $row['code_number'];
    endwhile;
    }
function check_code_send_state($id,$job,$user){
            global $con;
       $GLOBALS['query']="SELECT * FROM `jw_regestered_jobs` where jr_id= $id and job_id=$job and user_id=$user";
    $h_display_item=$con->prepare($GLOBALS['query']);
        $h_display_item->execute();
        $h_empty= $h_display_item->rowcount();

                   while($row=$h_display_item->fetch()) :
      if($row['code_number']!=null && $row['sure_id']==0)
            echo '<form action="deal.php?do=send" method="post">
                <input type="text" name="jobid" value="'.$job.'"  hidden="hidden">
                <input type="text" name="userid" value="'.$user.'"  hidden="hidden">
                <input name="id" value="'.$row['jr_id'].'" type="text"  hidden="hidden">
            <button type="submit" name="sendcode" class="btn btn-success"> السماح بظهور الوظيفة في صفحة المستخدم</button>
            <button type="submit" name="delcode" class="btn btn-warning"> الكود المرسل خطأ</button>
            <button type="submit" name="editcode" class="btn btn-danger">ارسال رسالة خطأ</button>
            </form>';
        elseif($row['code_number']!=null && $row['sure_id']==1)
            echo 'تم التعديل بنجاح';
      elseif($row['code_number']==null && $row['sure_id']==0)
            echo ' بأنتظار الكود';
    endwhile;
    }


    function check_login_erorr($state){
     if($state==0){
              echo'  
                 <section class=" user_message bg-danger" style="background-color:;margin-top: 70px;">
            <div class="container ">
                <div class="row">
                    <div class="col-12 text-center ">
                        <p> 
كلمة المرور او اسم المستخدم خاطئة</p>
                    </div>
               </div>
             </div>
           </section>
            ';
     }else{
     echo"";
     }
    }

function check_user_job($id){
            global $con;

       $GLOBALS['query']="SELECT * FROM `jw_regestered_jobs`,`jw_jobs` where jw_regestered_jobs.job_id= jw_jobs.id and jw_regestered_jobs.user_id=$id  ";
    $h_display_item=$con->prepare($GLOBALS['query']);
        $h_display_item->execute();
        $h_empty= $h_display_item->rowcount();
        if($h_empty>0){
                 while($row=$h_display_item->fetch()) :
       $GLOBALS['m']=$row['code_number'];
       $GLOBALS['j']=$row['sure_id'];
       $GLOBALS['ey']=$row['error_state'];
    endwhile;
            if($GLOBALS['m']==null && $GLOBALS['j']==0 && $GLOBALS['ey']==0){
            echo'  
                 <section class=" user_message">
            <div class="container ">
                <div class="row">
                    <div class="col-12 text-center ">
                        <p>
                    في إنتظار الموافقة من مسؤولي الموقع لدخولك القرعة للحصول على الوظيفة سوف نقوم بإبلاغك من خلال رسالة واتساب الى رقمك 
                        </p>
                    </div>
               </div>
             </div>
           </section>
            ';
            }elseif($GLOBALS['m'] != null && $GLOBALS['j']==1 && $GLOBALS['ey']==0){
              echo'  
                 <section class=" user_message">
            <div class="container ">
                <div class="row">
                    <div class="col-12 text-center ">
                        <p> 
    إذا تم اختيار اسمك من القرعة وربحتي الوظيفة سوف يتم ابلاغك من خلال رسالة واتساب الى رقمك 
                        </p>
                    </div>
               </div>
             </div>
           </section>
            ';
            }elseif($GLOBALS['m'] != null && $GLOBALS['j']==0){
              echo'  
                 <section class=" user_message">
            <div class="container ">
                <div class="row">
                    <div class="col-12 text-center ">
                        <p>
                    
تم ارسال كود التوثيق بنجاح                         </p>
                    </div>
               </div>
             </div>
           </section>
            ';
            }elseif($GLOBALS['m'] == null && $GLOBALS['j']==0 && $GLOBALS['ey']==1){
              echo'  
                 <section class=" user_message bg-danger">
            <div class="container ">
                <div class="row">
                    <div class="col-12 text-center ">
                        <p>
                  
الكود الذي تم ارساله لايوافق الكود المرسل الى رقم الواتساب الخاص بكم</p>
                    </div>
               </div>
             </div>
           </section>
            ';
            }
        }
    }
    function check_user_job_code_note($id){
            global $con;
       $GLOBALS['query']="SELECT * FROM `jw_regestered_jobs` WHERE code_number NOT LIKE 'NULL' and sure_id =1 and user_id=$id";
    $h_display_item=$con->prepare($GLOBALS['query']);
        $h_display_item->execute();
        $h_empty= $h_display_item->rowcount();
        if($h_empty > 0){
                 while($row=$h_display_item->fetch()) :
       $GLOBALS['k']=$row['code_number'];
       $GLOBALS['s']=$row['sure_id'];
    endwhile;
            if($GLOBALS['k'] != null && $GLOBALS['s'] ==1){
            echo'<a  href="myjobs.php?id=$id"> وظائفي</a>
            ';
            }else{echo "".$h_empty;}
        }
    }

    ?>