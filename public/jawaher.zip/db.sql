-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 25 سبتمبر 2020 الساعة 15:39
-- إصدار الخادم: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jawaher_db`
--

-- --------------------------------------------------------

--
-- بنية الجدول `jw_jobs`
--

DROP TABLE IF EXISTS `jw_jobs`;
CREATE TABLE IF NOT EXISTS `jw_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `publishdate` date NOT NULL,
  `jeha` text NOT NULL,
  `address` text NOT NULL,
  `startdate` text NOT NULL,
  `enddate` text NOT NULL,
  `description` text NOT NULL,
  `constracts` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `jw_jobs`
--

INSERT INTO `jw_jobs` (`id`, `name`, `publishdate`, `jeha`, `address`, `startdate`, `enddate`, `description`, `constracts`) VALUES
(7, 'bb', '2020-09-20', 'b', 'b', '2020-10-08', '2020-09-23', '                                b ', '                                g '),
(5, 'mm', '2020-09-20', 'mm', 'mm', '2020-10-07', '2020-09-13', '                                mmmmmmmmmmm ', '                                llll');

-- --------------------------------------------------------

--
-- بنية الجدول `jw_regestered_jobs`
--

DROP TABLE IF EXISTS `jw_regestered_jobs`;
CREATE TABLE IF NOT EXISTS `jw_regestered_jobs` (
  `jr_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code_number` int(11) DEFAULT NULL,
  `dateofregister` date NOT NULL,
  `code_send_status` int(11) NOT NULL DEFAULT '0',
  `sure_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`jr_id`),
  KEY `user_id` (`user_id`),
  KEY `job_id` (`job_id`,`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `jw_regestered_jobs`
--

INSERT INTO `jw_regestered_jobs` (`jr_id`, `job_id`, `user_id`, `code_number`, `dateofregister`, `code_send_status`, `sure_id`) VALUES
(1, 5, 1, 8888, '2020-09-10', 1, 1),
(2, 5, 1, 9999, '2020-09-10', 1, 1);

-- --------------------------------------------------------

--
-- بنية الجدول `jw_user`
--

DROP TABLE IF EXISTS `jw_user`;
CREATE TABLE IF NOT EXISTS `jw_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `con_password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `jw_user`
--

INSERT INTO `jw_user` (`id`, `name`, `email`, `password`, `con_password`) VALUES
(10, ' adm', 'admin@w', '42ef63e7836ef622d9185c1a456051edf16095cc', 'adm'),
(9, 'me', 'admin@w', 'd1854cae891ec7b29161ccaf79a24b00c274bdaa', 'n');

-- --------------------------------------------------------

--
-- بنية الجدول `jw_users`
--

DROP TABLE IF EXISTS `jw_users`;
CREATE TABLE IF NOT EXISTS `jw_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` text NOT NULL,
  `birthdate` text NOT NULL,
  `birthplace` text NOT NULL,
  `social` text NOT NULL,
  `whatsapp` text NOT NULL,
  `email` text NOT NULL,
  `city` text NOT NULL,
  `placeoflife` text NOT NULL,
  `street` text NOT NULL,
  `district` text NOT NULL,
  `buldingnumber` text NOT NULL,
  `zipcode` text NOT NULL,
  `additonalcode` text NOT NULL,
  `statenumber` text NOT NULL,
  `job` text NOT NULL,
  `jopplace` text NOT NULL,
  `user_name` text NOT NULL,
  `user_pass` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `jw_users`
--

INSERT INTO `jw_users` (`id`, `fullname`, `birthdate`, `birthplace`, `social`, `whatsapp`, `email`, `city`, `placeoflife`, `street`, `district`, `buldingnumber`, `zipcode`, `additonalcode`, `statenumber`, `job`, `jopplace`, `user_name`, `user_pass`) VALUES
(1, 'suad abdoh alwajeeh', '', 'sana\'a', 'marride', '777934439', 'sd.alwajeeh@gmail.com', 'sanaa', 'sanaa', 'mathbah', 'al lil', '55', '5668890', 'yyyyyy', 'hhhhh', 'programmer', 'hhh', 'soso', '5c4627345fc3e0c5574672d14f993d9bc8140b7f'),
(2, 'suad abdoh alwajeeh', '', 'sana\'a', 'marride', '967773444306', 'sd.alwajeeh@gmail.com', 'sanaa', 'sanaa', 'mathbah', 'al lil', '55', '5668890', 'yyyyyy', 'hhhhh', 'programmer', 'hhh', 'soso', 'soso'),
(14, 'monnnnnnnnnnnnnnnnna', '2020-09-15', 'nnn', 'll', '976777124392', 'nnnnnnnn@w', 'hh', 'nn', 'll', 'nnnnnnnnn', 'bb', 'kknn', '0', '0', 'iiii', 'pppp', 'bbb', '7e240de74fb1ed08fa08d38063f6a6a91462a815'),
(13, 'mmm', '2020-09-23', 'hhhhh', 'nnn', '7777777777', 'bbbbbbbb@www', 'iii', 'uuu', 'iiiiii', 'bbb', 'bbb', 'hhh', 'hhh', 'hhh', 'j', 'h', 'mmm', '91223fd10ce86fc852b449583aa2196c304bf6e0'),
(12, 'kkkkkkkkkkkkkkkk', '2020-09-28', 'b', 'bbbb', '888888888888', 'nn@ee', 'n', 'mm', 'mmm', 'b', 'n', 'j', 'kkk', 'mmmm', 'jjj', 'hhhh', 'nnn', '91223fd10ce86fc852b449583aa2196c304bf6e0'),
(11, 'nnm', '2020-09-14', 'n', 'kkkkkkkkkkkkk', 'hhhhhhhhh', 'nn@ee', 'jjjjjjjjjjjjjjj', 'kkkkkkkkkkkkkkkk', 'k', 'hhh', 'hhh', 'hhh', 'j', 'jj', 'i', 'k', 'hhh', '0343bb07c98f8a943e8eb80c0ba3d9758d372d22');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
